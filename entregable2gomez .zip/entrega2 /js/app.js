// app.js - Lógica del simulador de carrito
// Use módulos (type="module" en HTML) para mantener el espacio limpio.
// LocalStorage key:
const STORAGE_KEY = 'entregable2_cart_v1';
const PRODUCTS_KEY = 'entregable2_products_v1';

// DOM elements
const productListEl = document.getElementById('product-list');
const cartListEl = document.getElementById('cart-list');
const cartCountEl = document.getElementById('cart-count');
const cartTotalEl = document.getElementById('cart-total');
const addProductForm = document.getElementById('add-product-form');
const btnClearCart = document.getElementById('btn-clear-cart');
const btnSaveCart = document.getElementById('btn-save-cart');
const btnLoadCart = document.getElementById('btn-load-cart');

// Datos de la aplicación (arrays/objetos)
let products = []; // array de objetos {id,name,price,stock}
let cart = [];     // array de items {productId, quantity}

// --- Utilities ---
function formatMoney(value){
  return Number(value).toFixed(2);
}
function uid(){ return Math.random().toString(36).slice(2,9); }

// --- Storage management ---
function saveProductsToStorage(){
  localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
}
function loadProductsFromStorage(){
  const raw = localStorage.getItem(PRODUCTS_KEY);
  if(raw) products = JSON.parse(raw);
}
function saveCartToStorage(){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}
function loadCartFromStorage(){
  const raw = localStorage.getItem(STORAGE_KEY);
  if(raw) cart = JSON.parse(raw);
}

// --- Rendering ---
function renderProducts(){
  productListEl.innerHTML = '';
  products.forEach(p => {
    const div = document.createElement('div');
    div.className = 'product';
    div.innerHTML = `
      <div>
        <h4>${p.name}</h4>
        <small>Precio: ARS ${formatMoney(p.price)} — Stock: <span data-stock="${p.id}">${p.stock}</span></small>
      </div>
      <div class="meta">
        <button ${p.stock <= 0 ? 'disabled' : ''} data-add="${p.id}">Agregar al carrito</button>
      </div>
    `;
    productListEl.appendChild(div);
  });
  // attach event listeners in a homogeneous manner
  productListEl.querySelectorAll('button[data-add]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const productId = e.currentTarget.getAttribute('data-add');
      addToCart(productId, 1);
    });
  });
}

function renderCart(){
  cartListEl.innerHTML = '';
  if(cart.length === 0){
    cartListEl.innerHTML = '<p class="muted">El carrito está vacío.</p>';
  } else {
    cart.forEach(item => {
      const product = products.find(p => p.id === item.productId);
      const div = document.createElement('div');
      div.className = 'cart-item';
      div.innerHTML = `
        <div>
          <strong>${product.name}</strong> <small>(${formatMoney(product.price)} ARS)</small>
          <div style="font-size:13px;color:#555">Cantidad: <span data-qty="${item.productId}">${item.quantity}</span></div>
        </div>
        <div>
          <button data-remove="${item.productId}">Quitar</button>
        </div>
      `;
      cartListEl.appendChild(div);
    });

    // attach remove handlers
    cartListEl.querySelectorAll('button[data-remove]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const pid = e.currentTarget.getAttribute('data-remove');
        removeFromCart(pid);
      });
    });
  }

  // summary
  const totalItems = cart.reduce((s, it) => s + it.quantity, 0);
  const totalPrice = cart.reduce((s, it) => {
    const p = products.find(x => x.id === it.productId);
    return s + (p.price * it.quantity);
  }, 0);

  cartCountEl.textContent = totalItems;
  cartTotalEl.textContent = formatMoney(totalPrice);
}

// --- Business logic ---
function addToCart(productId, quantity){
  // validate entry
  const product = products.find(p => p.id === productId);
  if(!product) return;
  if(quantity <= 0) return;

  // check stock
  const cartItem = cart.find(i => i.productId === productId);
  const currentInCart = cartItem ? cartItem.quantity : 0;
  if(currentInCart + quantity > product.stock){
    
    showTemporaryMessage(`Stock insuficiente para "${product.name}"`);
    return;
  }

  if(cartItem){
    cartItem.quantity += quantity;
  } else {
    cart.push({ productId, quantity });
  }

  renderCart();
  saveCartToStorage();
}

function removeFromCart(productId){
  const itemIndex = cart.findIndex(i => i.productId === productId);
  if(itemIndex >= 0){
    cart.splice(itemIndex,1);
    renderCart();
    saveCartToStorage();
  }
}

function clearCart(){
  cart = [];
  renderCart();
  saveCartToStorage();
}

// Temporary message area (non-intrusive)
function showTemporaryMessage(text, timeout = 2500){
  let region = document.getElementById('tmp-msg');
  if(!region){
    region = document.createElement('div');
    region.id = 'tmp-msg';
    region.style.position = 'fixed';
    region.style.right = '20px';
    region.style.bottom = '20px';
    region.style.background = '#fef3c7';
    region.style.padding = '10px 14px';
    region.style.border = '1px solid #f59e0b';
    region.style.borderRadius = '8px';
    region.style.boxShadow = '0 2px 8px rgba(0,0,0,0.08)';
    document.body.appendChild(region);
  }
  region.textContent = text;
  region.style.display = 'block';
  setTimeout(()=> region.style.display = 'none', timeout);
}

// --- Form handlers ---
addProductForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const nameInput = document.getElementById('prod-name');
  const priceInput = document.getElementById('prod-price');
  const stockInput = document.getElementById('prod-stock');

  // Create product object
  const newProduct = {
    id: uid(),
    name: nameInput.value.trim() || 'Sin nombre',
    price: Number(priceInput.value) || 0,
    stock: Number(stockInput.value) || 0
  };

  // push to array and persist
  products.push(newProduct);
  saveProductsToStorage();

  // reset form and re-render
  addProductForm.reset();
  renderProducts();
  showTemporaryMessage('Producto agregado');
});

// cart action buttons
btnClearCart.addEventListener('click', () => {
  clearCart();
  showTemporaryMessage('Carrito vaciado');
});

btnSaveCart.addEventListener('click', () => {
  saveCartToStorage();
  showTemporaryMessage('Simulación guardada en localStorage');
});

btnLoadCart.addEventListener('click', () => {
  loadCartFromStorage();
  renderCart();
  showTemporaryMessage('Simulación cargada desde localStorage');
});

// --- Initialization ---
// If there are no products in storage, seed with some demo products
function seedProducts(){
  products = [
    {"id": "p1", "name": "Remera Banda", "price": 3500.0, "stock": 10},
    {"id": "p2", "name": "Gorra", "price": 1200.5, "stock": 8},
    {"id": "p3", "name": "CD Edici\u00f3n", "price": 2500.0, "stock": 5},
    {"id": "p4", "name": "Entrada VIP (simulada)", "price": 8000.0, "stock": 2}
  ];
  saveProductsToStorage();
}

// Boot sequence
(function init(){
  loadProductsFromStorage();
  if(!products || products.length === 0){
    seedProducts();
  }
  loadCartFromStorage();
  renderProducts();
  renderCart();
})();
