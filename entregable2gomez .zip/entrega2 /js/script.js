let gastos = JSON.parse(localStorage.getItem("gastos")) || [];

const gastoForm = document.getElementById("gastoForm");
const nombreGasto = document.getElementById("nombreGasto");
const montoGasto = document.getElementById("montoGasto");
const gastosContainer = document.getElementById("gastosContainer");
const totalGastos = document.getElementById("totalGastos");
const resetBtn = document.getElementById("resetBtn");

function mostrarGastos() {
  gastosContainer.innerHTML = "";
  let total = 0;

  gastos.forEach((gasto, index) => {
    const li = document.createElement("li");
    li.innerHTML = `
      ${gasto.nombre} - $${gasto.monto}
      <button class="borrar" data-index="${index}">❌</button>
    `;
    gastosContainer.appendChild(li);
    total += gasto.monto;
  });

  totalGastos.textContent = total;
  localStorage.setItem("gastos", JSON.stringify(gastos));
}

gastoForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const nombre = nombreGasto.value.trim();
  const monto = parseFloat(montoGasto.value);

  if (nombre && monto > 0) {
    gastos.push({ nombre, monto });
    mostrarGastos();
    gastoForm.reset();
  }
});

gastosContainer.addEventListener("click", (e) => {
  if (e.target.classList.contains("borrar")) {
    const index = e.target.dataset.index;
    gastos.splice(index, 1);
    mostrarGastos();
  }
});

resetBtn.addEventListener("click", () => {
  if (confirm("¿Seguro que quieres reiniciar el simulador?")) {
    gastos = [];
    mostrarGastos();
    localStorage.removeItem("gastos");
  }
});

mostrarGastos();