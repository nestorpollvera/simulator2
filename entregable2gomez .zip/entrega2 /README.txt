Simulador de Gastos Mensuales - Entregable 2 (Néstor Gómez)

Este proyecto simula el registro y control de gastos mensuales.
Permite agregar, eliminar y calcular el total de gastos, 
almacenando los datos en localStorage para mantenerlos tras recargar la página.

Estructura:
- index.html → interfaz principal
- css/style.css → estilos
- js/script.js → lógica con DOM y eventos
